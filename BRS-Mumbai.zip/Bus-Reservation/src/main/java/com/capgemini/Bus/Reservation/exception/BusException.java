package com.capgemini.Bus.Reservation.exception;

public class BusException extends Exception{

	public BusException() {
		super();
		
	}

	public BusException(String message) {
		super(message);
		
	}
	
	

}
